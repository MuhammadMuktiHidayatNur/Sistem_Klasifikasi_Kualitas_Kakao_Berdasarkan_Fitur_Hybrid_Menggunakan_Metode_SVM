import os
import numpy as np
from flask import Flask, render_template, request, redirect, url_for
from PIL import Image
import joblib

# Inisialisasi Flask
app = Flask(__name__)

# Path untuk menyimpan file yang diunggah
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Pastikan folder 'uploads' ada
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load model SVM
model = joblib.load('svm_model3.pkl')
class_labels = {0: "Busuk", 1: "Matang", 2: "Mentah"}

# Fungsi preprocessing gambar
def preprocess_image(file_content):
    # Membuka gambar dari file content
    img = Image.open(file_content)
    # Konversi ke grayscale
    img = img.convert('L')
    # Resize gambar sesuai kebutuhan model
    img = img.resize((128, 128))
    # Konversi ke array numpy
    img_array = np.array(img) / 255.0  # Normalisasi
    # Flatten jika model membutuhkan array 1D
    img_array = img_array.flatten().reshape(1, -1)
    return img_array

def is_valid_kakao_image(img_path):
    img = Image.open(img_path).convert('RGB')
    img = img.resize((128, 128))
    img_array = np.array(img)

    # Hitung rata-rata warna (RGB)
    mean_color = img_array.mean(axis=(0,1))  # shape: (3,)
    
    # Buah kakao biasanya memiliki warna dominan di rentang ini
    r, g, b = mean_color
    if (40 <= r <= 185) and (30 < g <= 180) and (b < 120 or b <= 175):
        return True
    return False


# Route utama
@app.route('/', methods=['GET', 'POST'])

def index():
    if request.method == 'POST':
        # Ambil file dari form upload
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        
        # Simpan file yang diunggah
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        #Validasi
        if not is_valid_kakao_image(file_path):
            os.remove(file_path)  # Hapus file yang tidak valid
            return render_template('index.html', uploaded_image=None, result="Gambar bukan buah kakao!")
        
        # Preprocessing dan klasifikasi gambar
        processed_image = preprocess_image(file_path)
        prediction = model.predict(processed_image)[0]
        predicted_label = class_labels[prediction]

        return render_template('index.html', uploaded_image=file.filename, result=predicted_label)

    return render_template('index.html', uploaded_image=None, result=None)


# Jalankan aplikasi
if __name__ == '__main__':
    app.run(debug=True)